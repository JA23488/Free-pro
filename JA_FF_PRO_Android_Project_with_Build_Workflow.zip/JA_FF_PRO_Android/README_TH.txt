JA FF PRO - Android project

นี่คือซอร์สโปรเจกต์ Android ไม่ใช่ไฟล์ APK ที่ติดตั้งได้ทันที

รายละเอียด:
- แอป Android ใช้ WebView แสดงหน้าจอ JA FF PRO
- Aim Assist เป็นเพียง UI จำลองภายในแอป ไม่ควบคุม Free Fire จริง
- เมนูลอยและการลากไอคอนทำงานภายในหน้าจอแอป ไม่ใช่ overlay ทับเกมอื่น
- ปุ่มเปิดเกมใช้ intent ที่อาจถูกเบราว์เซอร์/ระบบ Android จำกัดไว้ในตัวอย่าง HTML

วิธีสร้าง APK ต้องใช้ Android Studio หรือสภาพแวดล้อม build ที่มี Android SDK และ Gradle
คำสั่งจากโฟลเดอร์โปรเจกต์: gradle assembleDebug
ไฟล์ APK เมื่อ build สำเร็จจะอยู่ที่ app/build/outputs/apk/debug/app-debug.apk


วิธีสร้าง APK โดยใช้โทรศัพท์อย่างเดียว (ผ่าน GitHub Actions):
1. แตกไฟล์ ZIP แล้วอัปโหลดเนื้อหาในโฟลเดอร์ JA_FF_PRO_Android เข้า repository ใหม่บน GitHub
2. ต้องให้ไฟล์ .github/workflows/android.yml อยู่ที่ระดับบนสุดของ repository
3. เปิดแท็บ Actions แล้วเลือก "Build JA FF PRO APK"
4. กด "Run workflow" และรอให้สถานะเป็นสีเขียว
5. เปิดงาน build ที่เสร็จแล้ว เลื่อนลงไปที่ Artifacts แล้วดาวน์โหลด JA-FF-PRO-debug-apk
6. แตกไฟล์ artifact ZIP ที่ดาวน์โหลด จะพบ app-debug.apk แล้วติดตั้งบน Android

หมายเหตุ: GitHub ต้องมีบัญชีและ repository ที่เปิดใช้ Actions ได้ ไฟล์ APK ที่ได้เป็น debug build สำหรับทดสอบ
